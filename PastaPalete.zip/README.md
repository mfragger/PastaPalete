# Pasta Palete

[Site Here](https://mfragger.github.io/PastaPalete/index.html)

A simple pasta themed website made using traditional html stuff without a framework.

For css, I used tailwind.